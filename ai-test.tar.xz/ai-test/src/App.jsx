import { useState, useRef, useEffect } from "react";
import * as mammoth from "mammoth";

const C = {
  purple: { solid: "#534AB7", light: "#EEEDFE", mid: "#AFA9EC", dark: "#3C3489", text: "#26215C" },
  teal:   { solid: "#0F6E56", light: "#E1F5EE", mid: "#5DCAA5", dark: "#085041", text: "#04342C" },
  coral:  { solid: "#993C1D", light: "#FAECE7", mid: "#F0997B", dark: "#712B13", text: "#4A1B0C" },
  blue:   { solid: "#185FA5", light: "#E6F1FB", mid: "#85B7EB", dark: "#0C447C", text: "#042C53" },
  amber:  { solid: "#BA7517", light: "#FAEEDA", mid: "#EF9F27", dark: "#633806", text: "#412402" },
  pink:   { solid: "#993556", light: "#FBEAF0", mid: "#ED93B1", dark: "#72243E", text: "#4B1528" },
};

const TIERS = [
  { label: "IIT / IISc", score: 100, color: C.purple },
  { label: "NIT / BITS", score: 80, color: C.teal },
  { label: "Central university", score: 70, color: C.blue },
  { label: "State university", score: 50, color: C.amber },
  { label: "District / private college", score: 30, color: C.coral },
];

function AnimBar({ pct, color, delay = 0, height = 20 }) {
  const [w, setW] = useState(0);
  useEffect(() => { const t = setTimeout(() => setW(pct), delay); return () => clearTimeout(t); }, [pct, delay]);
  return (
    <div style={{ background: "#e8e8e8", borderRadius: 99, height, overflow: "hidden", flex: 1 }}>
      <div style={{ height: "100%", borderRadius: 99, background: color, width: `${w}%`, transition: "width 1.3s cubic-bezier(.4,0,.2,1)", display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 10 }}>
        {w > 12 && <span style={{ color: "#fff", fontSize: 11, fontWeight: 500 }}>{Math.round(pct)}%</span>}
      </div>
    </div>
  );
}

function Dial({ pct, color, size = 110, delay = 0 }) {
  const [v, setV] = useState(0);
  useEffect(() => { const t = setTimeout(() => setV(pct), delay); return () => clearTimeout(t); }, [pct, delay]);
  const r = size * 0.38, circ = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#e0e0e0" strokeWidth={size*0.075} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={size*0.075}
        strokeDasharray={`${circ * v / 100} ${circ}`} strokeLinecap="round"
        transform={`rotate(-90 ${size/2} ${size/2})`}
        style={{ transition: "stroke-dasharray 1.5s cubic-bezier(.4,0,.2,1)" }} />
      <text x={size/2} y={size/2 + 7} textAnchor="middle" fontSize={size*0.22} fontWeight="500" fill={color}>{Math.round(v)}%</text>
    </svg>
  );
}

function DropZone({ label, sub, file, onFile, accent }) {
  const ref = useRef(); const [drag, setDrag] = useState(false);
  const onDrop = e => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) onFile(f); };
  return (
    <div onClick={() => ref.current.click()} onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={onDrop}
      style={{ border: `2px dashed ${file ? accent.solid : drag ? accent.mid : "#d0d0d0"}`, borderRadius: 16, padding: "32px 20px", textAlign: "center", cursor: "pointer", background: file ? accent.light : drag ? accent.light + "88" : "transparent", transition: "all .2s" }}>
      <input ref={ref} type="file" accept=".pdf,.docx,.txt" style={{ display: "none" }} onChange={e => onFile(e.target.files[0])} />
      <div style={{ width: 48, height: 48, borderRadius: 12, background: file ? accent.solid : accent.light, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px" }}>
        <i className={`ti ${file ? "ti-check" : "ti-upload"}`} style={{ fontSize: 22, color: file ? "#fff" : accent.solid }} aria-hidden="true" />
      </div>
      {file
        ? <><p style={{ margin: 0, fontWeight: 500, fontSize: 13, color: accent.dark }}>{file.name}</p><p style={{ margin: "4px 0 0", fontSize: 11, color: accent.solid }}>Click to replace</p></>
        : <><p style={{ margin: 0, fontWeight: 500, fontSize: 14, color: "var(--color-text-primary)" }}>{label}</p><p style={{ margin: "4px 0 0", fontSize: 12, color: "var(--color-text-secondary)" }}>{sub}</p></>
      }
    </div>
  );
}

async function extractText(file) {
  if (!file) return "";
  const n = file.name.toLowerCase();
  if (n.endsWith(".txt")) return new Promise(r => { const fr = new FileReader(); fr.onload = e => r(e.target.result); fr.readAsText(file); });
  if (n.endsWith(".docx")) return new Promise(async r => { try { const ab = await file.arrayBuffer(); const res = await mammoth.extractRawText({ arrayBuffer: ab }); r(res.value); } catch { r(""); } });
  if (n.endsWith(".pdf")) {
    return new Promise(async r => {
      const ab = await file.arrayBuffer();
      if (!window.pdfjsLib) { r(""); return; }
      const pdf = await window.pdfjsLib.getDocument({ data: ab }).promise;
      let t = "";
      for (let i = 1; i <= pdf.numPages; i++) { const pg = await pdf.getPage(i); const c = await pg.getTextContent(); t += c.items.map(s => s.str).join(" ") + "\n"; }
      r(t);
    });
  }
  return "";
}

const FEATURES = [
  { icon: "ti-target", label: "Career goal match", desc: "Aligns candidate objective with role requirements", color: C.purple },
  { icon: "ti-bolt", label: "Skills analysis", desc: "Matches technical and soft skills against JD", color: C.teal },
  { icon: "ti-school", label: "College tier scoring", desc: "IIT → NIT → Central → State → District", color: C.blue },
  { icon: "ti-chart-bar", label: "Visual score report", desc: "Colourful charts with instant hire recommendation", color: C.coral },
];

const STEPS = [
  { num: "01", label: "Upload JD", desc: "Drop your job description — PDF, DOCX, or TXT", color: C.purple },
  { num: "02", label: "Upload resume", desc: "Add the candidate's resume in any format", color: C.teal },
  { num: "03", label: "AI screening", desc: "Our AI reads, compares and scores in seconds", color: C.blue },
  { num: "04", label: "Get results", desc: "Shortlist, Consider, or Reject — with full breakdown", color: C.coral },
];

// ── Gemini API call via local proxy ──────────────────────────────────────────
// The proxy (gemini_proxy.py) forwards requests to Google's Generative Language API.
// Proxy must be running at http://127.0.0.1:8787 before using this tool.
async function callGemini(prompt) {
  const res = await fetch("http://127.0.0.1:8787/v1/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
  // Gemini response: candidates[0].content.parts[0].text
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}
// ─────────────────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState("home");
  const [jd, setJd] = useState(null);
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [err, setErr] = useState("");

  const analyze = async () => {
    if (!jd || !resume) { setErr("Please upload both files."); return; }
    setErr(""); setLoading(true);
    try {
      const [jdTxt, resTxt] = await Promise.all([extractText(jd), extractText(resume)]);
      const prompt = `You are an expert HR analyst. Analyze this resume vs the job description. Return ONLY valid JSON, no markdown, no explanation.

JOB DESCRIPTION:
${jdTxt.slice(0, 3000)}

RESUME:
${resTxt.slice(0, 3000)}

Return exactly:
{"career_match":<0-100>,"career_summary":"<2 sentences>","skills_match":<0-100>,"skills_summary":"<2 sentences>","matched_skills":["..."],"missing_skills":["..."],"college_name":"<name or Not mentioned>","college_tier":"<IIT/IISc|NIT/BITS|Central University|State University|District/Private College|Not mentioned>","college_score":<100|80|70|50|30|0>,"overall_recommendation":"<Shortlist|Consider|Reject>","recommendation_reason":"<2 sentences>"}`;

      const raw = await callGemini(prompt);
      // Robustly extract JSON: find first { and last } to handle markdown fences,
      // preamble text, or any trailing content from the model.
      const jsonStart = raw.indexOf("{");
      const jsonEnd   = raw.lastIndexOf("}");
      if (jsonStart === -1 || jsonEnd === -1) throw new Error("No JSON object found in response");
      const jsonStr = raw.slice(jsonStart, jsonEnd + 1);
      setResult(JSON.parse(jsonStr));
      setPage("result");
    } catch (e) { setErr("Analysis failed: " + e.message); }
    finally { setLoading(false); }
  };

  const reset = () => { setJd(null); setResume(null); setResult(null); setErr(""); setPage("tool"); };

  const recMeta = result ? (
    result.overall_recommendation === "Shortlist" ? { color: C.teal, icon: "ti-circle-check", label: "Shortlist" } :
    result.overall_recommendation === "Consider"  ? { color: C.amber, icon: "ti-circle-dot", label: "Consider" } :
    { color: C.coral, icon: "ti-circle-x", label: "Reject" }
  ) : null;

  const tierColor = result ? (TIERS.find(t => t.score === result.college_score)?.color || C.coral) : C.coral;

  if (page === "home") return (
    <div style={{ fontFamily: "var(--font-sans)" }}>
      <div style={{ background: C.purple.light, borderRadius: 20, padding: "48px 36px 40px", marginBottom: 24, position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -40, right: -40, width: 200, height: 200, borderRadius: "50%", background: C.purple.mid, opacity: 0.25 }} />
        <div style={{ position: "absolute", bottom: -30, left: "40%", width: 140, height: 140, borderRadius: "50%", background: C.teal.mid, opacity: 0.2 }} />
        <div style={{ position: "relative" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: C.purple.solid, borderRadius: 99, padding: "6px 14px", marginBottom: 20 }}>
            <i className="ti ti-sparkles" style={{ fontSize: 14, color: "#fff" }} aria-hidden="true" />
            <span style={{ color: "#fff", fontSize: 12, fontWeight: 500 }}>Powered by Gemini AI</span>
          </div>
          <h1 style={{ margin: "0 0 12px", fontSize: 32, fontWeight: 500, color: C.purple.text, lineHeight: 1.2 }}>Resume Filter AI</h1>
          <p style={{ margin: "0 0 8px", fontSize: 17, color: C.purple.dark, maxWidth: 480 }}>AI-powered resume screener for modern HR teams. Upload a JD and resume — get instant, objective shortlisting decisions.</p>
          <p style={{ margin: "0 0 28px", fontSize: 13, color: C.purple.solid }}>No more manual screening. No bias. Just data.</p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <button onClick={() => setPage("tool")} style={{ background: C.purple.solid, color: "#fff", border: "none", borderRadius: 12, padding: "14px 28px", fontSize: 15, fontWeight: 500, cursor: "pointer" }}>
              Start screening <i className="ti ti-arrow-right" style={{ fontSize: 14, marginLeft: 6 }} aria-hidden="true" />
            </button>
            <button onClick={() => setPage("tool")} style={{ background: "#fff", color: C.purple.solid, border: `1.5px solid ${C.purple.solid}`, borderRadius: 12, padding: "14px 24px", fontSize: 15, fontWeight: 500, cursor: "pointer" }}>
              See how it works
            </button>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 24 }}>
        {FEATURES.map(f => (
          <div key={f.label} style={{ background: f.color.light, borderRadius: 16, padding: "20px 18px", border: `1px solid ${f.color.mid}` }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: f.color.solid, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
              <i className={`ti ${f.icon}`} style={{ fontSize: 20, color: "#fff" }} aria-hidden="true" />
            </div>
            <p style={{ margin: "0 0 4px", fontWeight: 500, fontSize: 14, color: f.color.text }}>{f.label}</p>
            <p style={{ margin: 0, fontSize: 12, color: f.color.dark }}>{f.desc}</p>
          </div>
        ))}
      </div>

      <div style={{ background: "#f8f6ff", borderRadius: 20, padding: "28px 24px", marginBottom: 24, border: `1px solid ${C.purple.mid}` }}>
        <p style={{ margin: "0 0 20px", fontWeight: 500, fontSize: 15, color: C.purple.text }}>How it works — 4 simple steps</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {STEPS.map(s => (
            <div key={s.num} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: s.color.solid, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <span style={{ color: "#fff", fontSize: 12, fontWeight: 500 }}>{s.num}</span>
              </div>
              <div>
                <p style={{ margin: "0 0 2px", fontWeight: 500, fontSize: 13, color: s.color.text }}>{s.label}</p>
                <p style={{ margin: 0, fontSize: 12, color: "var(--color-text-secondary)" }}>{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 24 }}>
        {[
          { val: "< 10s", label: "Screening time", color: C.teal },
          { val: "3 criteria", label: "Scored dimensions", color: C.purple },
          { val: "100%", label: "Objective analysis", color: C.blue },
        ].map(s => (
          <div key={s.label} style={{ background: s.color.light, borderRadius: 14, padding: "18px 14px", textAlign: "center", border: `1px solid ${s.color.mid}` }}>
            <p style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 500, color: s.color.solid }}>{s.val}</p>
            <p style={{ margin: 0, fontSize: 12, color: s.color.dark }}>{s.label}</p>
          </div>
        ))}
      </div>

      <button onClick={() => setPage("tool")} style={{ width: "100%", background: C.purple.solid, color: "#fff", border: "none", borderRadius: 14, padding: "16px", fontSize: 15, fontWeight: 500, cursor: "pointer" }}>
        <i className="ti ti-rocket" style={{ fontSize: 16, marginRight: 8 }} aria-hidden="true" />
        Start screening resumes for free
      </button>
    </div>
  );

  if (page === "tool") return (
    <div style={{ fontFamily: "var(--font-sans)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24, padding: "14px 0", borderBottom: `1px solid ${C.purple.light}` }}>
        <button onClick={() => setPage("home")} style={{ background: C.purple.light, border: "none", borderRadius: 8, padding: "6px 12px", cursor: "pointer", color: C.purple.solid, fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}>
          <i className="ti ti-arrow-left" style={{ fontSize: 14 }} aria-hidden="true" /> Home
        </button>
        <div>
          <p style={{ margin: 0, fontWeight: 500, fontSize: 16, color: "var(--color-text-primary)" }}>Resume Filter AI</p>
          <p style={{ margin: 0, fontSize: 12, color: "var(--color-text-secondary)" }}>Upload JD + Resume to begin</p>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <div style={{ width: 24, height: 24, borderRadius: 6, background: C.purple.solid, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontSize: 11, fontWeight: 500 }}>1</span>
            </div>
            <span style={{ fontSize: 13, fontWeight: 500, color: C.purple.dark }}>Job description</span>
          </div>
          <DropZone label="Upload job description" sub="PDF, DOCX, or TXT" file={jd} onFile={setJd} accent={C.purple} />
        </div>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <div style={{ width: 24, height: 24, borderRadius: 6, background: C.teal.solid, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontSize: 11, fontWeight: 500 }}>2</span>
            </div>
            <span style={{ fontSize: 13, fontWeight: 500, color: C.teal.dark }}>Candidate resume</span>
          </div>
          <DropZone label="Upload resume" sub="PDF, DOCX, or TXT" file={resume} onFile={setResume} accent={C.teal} />
        </div>
      </div>

      {err && <div style={{ background: C.coral.light, border: `1px solid ${C.coral.mid}`, borderRadius: 10, padding: "10px 14px", marginBottom: 14, fontSize: 13, color: C.coral.dark }}>{err}</div>}

      <button onClick={analyze} disabled={!jd || !resume || loading} style={{
        width: "100%", padding: "16px", borderRadius: 14, border: "none",
        background: jd && resume && !loading ? C.purple.solid : "#ccc",
        color: "#fff", fontSize: 15, fontWeight: 500, cursor: jd && resume && !loading ? "pointer" : "not-allowed"
      }}>
        {loading
          ? <><i className="ti ti-loader" style={{ fontSize: 16, marginRight: 8, animation: "spin 1s linear infinite", display: "inline-block" }} aria-hidden="true" />Analysing with Gemini AI...</>
          : <><i className="ti ti-sparkles" style={{ fontSize: 16, marginRight: 8 }} aria-hidden="true" />Screen this resume</>
        }
      </button>

      <div style={{ marginTop: 20, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
        {[
          { icon: "ti-target", label: "Career match", color: C.purple },
          { icon: "ti-bolt", label: "Skills match", color: C.teal },
          { icon: "ti-school", label: "College tier", color: C.blue },
        ].map(f => (
          <div key={f.label} style={{ background: f.color.light, borderRadius: 12, padding: "14px 12px", textAlign: "center", border: `1px solid ${f.color.mid}` }}>
            <i className={`ti ${f.icon}`} style={{ fontSize: 20, color: f.color.solid, display: "block", marginBottom: 6 }} aria-hidden="true" />
            <p style={{ margin: 0, fontSize: 12, fontWeight: 500, color: f.color.dark }}>{f.label}</p>
          </div>
        ))}
      </div>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  if (page === "result" && result) return (
    <div style={{ fontFamily: "var(--font-sans)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button onClick={reset} style={{ background: C.purple.light, border: "none", borderRadius: 8, padding: "6px 12px", cursor: "pointer", color: C.purple.solid, fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}>
            <i className="ti ti-arrow-left" style={{ fontSize: 14 }} aria-hidden="true" /> New
          </button>
          <div>
            <p style={{ margin: 0, fontWeight: 500, fontSize: 15, color: "var(--color-text-primary)" }}>Screening results</p>
            <p style={{ margin: 0, fontSize: 11, color: "var(--color-text-secondary)" }}>{resume?.name}</p>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: recMeta.color.light, border: `1.5px solid ${recMeta.color.solid}`, borderRadius: 99, padding: "8px 18px" }}>
          <i className={`ti ${recMeta.icon}`} style={{ fontSize: 16, color: recMeta.color.solid }} aria-hidden="true" />
          <span style={{ fontSize: 13, fontWeight: 500, color: recMeta.color.dark }}>{recMeta.label}</span>
        </div>
      </div>

      <div style={{ background: recMeta.color.light, border: `1px solid ${recMeta.color.mid}`, borderRadius: 14, padding: "14px 18px", marginBottom: 20 }}>
        <p style={{ margin: 0, fontSize: 13, color: recMeta.color.dark, lineHeight: 1.6 }}>{result.recommendation_reason}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 20 }}>
        {[
          { label: "Career goal match", pct: result.career_match, color: C.purple },
          { label: "Skills match", pct: result.skills_match, color: C.teal },
          { label: "College tier score", pct: result.college_score, color: tierColor },
        ].map((s, i) => (
          <div key={s.label} style={{ background: s.color.light, borderRadius: 16, padding: "20px 14px", textAlign: "center", border: `1px solid ${s.color.mid}` }}>
            <Dial pct={s.pct} color={s.color.solid} delay={i * 200} />
            <p style={{ margin: "10px 0 0", fontSize: 12, fontWeight: 500, color: s.color.dark }}>{s.label}</p>
          </div>
        ))}
      </div>

      <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 16, padding: "20px", marginBottom: 16 }}>
        <p style={{ margin: "0 0 18px", fontWeight: 500, fontSize: 15, color: "var(--color-text-primary)" }}>Score breakdown</p>
        {[
          { label: "Career / Objective match", pct: result.career_match, color: C.purple.solid, note: result.career_summary },
          { label: "Skills match", pct: result.skills_match, color: C.teal.solid, note: result.skills_summary },
          { label: `College tier — ${result.college_tier}`, pct: result.college_score, color: tierColor.solid, note: `Detected: ${result.college_name}` },
        ].map((row, i) => (
          <div key={row.label} style={{ marginBottom: i < 2 ? 18 : 0 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span style={{ fontSize: 13, fontWeight: 500, color: "var(--color-text-primary)" }}>{row.label}</span>
              <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>{Math.round(row.pct)}%</span>
            </div>
            <AnimBar pct={row.pct} color={row.color} delay={i * 200 + 400} height={18} />
            <p style={{ margin: "5px 0 0", fontSize: 12, color: "var(--color-text-secondary)", lineHeight: 1.5 }}>{row.note}</p>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
        <div style={{ background: C.teal.light, borderRadius: 14, padding: "16px", border: `1px solid ${C.teal.mid}` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <i className="ti ti-circle-check" style={{ fontSize: 16, color: C.teal.solid }} aria-hidden="true" />
            <p style={{ margin: 0, fontSize: 13, fontWeight: 500, color: C.teal.dark }}>Matched skills</p>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {(result.matched_skills || []).map(s => (
              <span key={s} style={{ background: C.teal.solid, color: "#fff", borderRadius: 99, padding: "4px 10px", fontSize: 11, fontWeight: 500 }}>{s}</span>
            ))}
            {(!result.matched_skills?.length) && <span style={{ fontSize: 12, color: C.teal.dark }}>None detected</span>}
          </div>
        </div>
        <div style={{ background: C.coral.light, borderRadius: 14, padding: "16px", border: `1px solid ${C.coral.mid}` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <i className="ti ti-circle-x" style={{ fontSize: 16, color: C.coral.solid }} aria-hidden="true" />
            <p style={{ margin: 0, fontSize: 13, fontWeight: 500, color: C.coral.dark }}>Missing skills</p>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {(result.missing_skills || []).map(s => (
              <span key={s} style={{ background: C.coral.solid, color: "#fff", borderRadius: 99, padding: "4px 10px", fontSize: 11, fontWeight: 500 }}>{s}</span>
            ))}
            {(!result.missing_skills?.length) && <span style={{ fontSize: 12, color: C.coral.dark }}>None missing</span>}
          </div>
        </div>
      </div>

      <div style={{ background: "#f8f6ff", borderRadius: 16, padding: "18px 20px", border: `1px solid ${C.purple.mid}` }}>
        <p style={{ margin: "0 0 14px", fontSize: 13, fontWeight: 500, color: C.purple.dark }}>College tier reference</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {TIERS.map(t => (
            <div key={t.label} style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 12, color: "var(--color-text-secondary)", width: 180, flexShrink: 0 }}>{t.label}</span>
              <div style={{ flex: 1, background: "#e0e0e0", borderRadius: 99, height: 14, overflow: "hidden" }}>
                <div style={{ width: `${t.score}%`, height: "100%", background: t.color.solid, borderRadius: 99 }} />
              </div>
              <span style={{ fontSize: 12, fontWeight: 500, color: t.color.solid, width: 34, textAlign: "right" }}>{t.score}%</span>
              {result.college_tier === t.label && (
                <span style={{ background: t.color.solid, color: "#fff", fontSize: 10, borderRadius: 99, padding: "2px 8px", fontWeight: 500, flexShrink: 0 }}>candidate</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return null;
}